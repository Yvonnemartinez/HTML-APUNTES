const numero1=30;
const numero2=50;
let resultado; //no puede ser una constante porque tendría que darle un valor
//suma:
resultado= numero1+numero2;
console.log(resultado);
//resta:
resultado= numero1- numero2;
console.log( `el resultado de la resta es ${resultado}`);
//multiplicación
resultado= numero1* numero2;
console.log(resultado);
//división
resultado= numero1 / numero2;
console.log( `El resultado de la divición es ${resultado}`);
