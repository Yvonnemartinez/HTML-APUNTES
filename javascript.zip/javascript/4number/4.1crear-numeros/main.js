const numeroEntero= 28;
console.log(numeroEntero);

const numeroFloat=28.20;
console.log(numeroFloat);

const numeroNegativo= -1;
console.log(numeroNegativo);
const noSoyNumero="30";
console.log(typeof noSoyNumero);