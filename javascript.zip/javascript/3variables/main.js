let empezar="Esta es mi primera variable"
console.log(empezar);
document.querySelector(".variables-ejemplo").innerHTML = `${empezar}`;
empezar= 4;
console.log(empezar);
document.querySelector(".variables-ejemplo").innerHTML=`Ahora mi variable empezar vale: ${empezar}`
let empezarDos=2;
console.log(empezarDos);
// empezar= true;
// console.log(empezar);
conts numeros= 1;
console.log(numeros);